<?php

return array(

	/*
	 *  You can set the API Key here
	 */

	'key' => 'AIzaSyAsaksixbvwTyTdXuYoyooitplftJnDBSstooonme'

);